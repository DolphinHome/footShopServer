<?php
// +----------------------------------------------------------------------
// | 中犇单商户
// +----------------------------------------------------------------------
// | Copyright (c) 2019-2021 中犇科技 All rights reserved.
// +----------------------------------------------------------------------

namespace app\shop\api\controller\v1;

use app\api\controller\Base;
use service\ApiReturn;

/**
 * 附近门店管理接口
 *@author chenchen
 */
class Index extends Base
{

public function index($data= [],$user = [])
{

}

}
